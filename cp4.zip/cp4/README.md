# Projeto de Business Intelligence e ETL de Vendas

Este projeto implementa um processo completo de **ETL (Extração, Transformação e Carga)** para migrar dados de um sistema transacional de vendas para um **Data Warehouse (DW)** otimizado para análises, seguindo o modelo Star Schema.

O objetivo é consolidar os dados e permitir a criação de dashboards analíticos para responder a perguntas de negócio chave, como volume de vendas, rentabilidade de produtos e perfil de consumo dos clientes.

---

## 🏗️ Estrutura do Projeto

O projeto é composto por três componentes principais:

- **Data Warehouse (DW):** Um conjunto de tabelas no formato Estrela (`FATO_VENDAS` e 5 Dimensões) projetadas para alta performance em consultas analíticas.  
- **Processo de ETL:** Um `PACKAGE` Oracle PL/SQL (`PKG_ETL_VENDAS`) que contém `PROCEDUREs` responsáveis por extrair, transformar (limpar, padronizar, tratar nulos) e carregar os dados no DW.  
- **Dashboard Analítico:** Um painel em Power BI que se conecta ao DW para fornecer visualizações interativas dos dados.  

---

## 🚀 Como Executar

Para recriar e popular o ambiente do Data Warehouse, execute os scripts SQL na seguinte ordem:

1. **`1_CRIACAO_AMBIENTE_DW.sql`** → Apaga qualquer estrutura antiga e cria as tabelas de Dimensão, Fato e as `SEQUENCEs` necessárias.  
2. **`2_PACKAGE_ETL.sql`** → Compila o `PACKAGE SPEC` e o `PACKAGE BODY` com toda a lógica de ETL.  
3. **`3_TRIGGER_E_EXECUCAO.sql`** → Cria a `TRIGGER` de auditoria e, em seguida, executa o processo de carga completo chamando a procedure `PKG_ETL_VENDAS.PRC_CARGA_GERAL_ETL`.  

---

## 📚 Dicionário de Dados - Data Warehouse de Vendas

Este documento detalha a estrutura das tabelas do modelo estrela (Star Schema) desenvolvido para a análise de vendas.

---

### 🔹 Tabela de Fatos: `FATO_VENDAS`

**Descrição:** Tabela central que armazena as métricas quantitativas de cada item de um pedido de venda.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_CLIENTE**      | `NUMBER(10)`    | PK/FK | Chave estrangeira para a `DIM_CLIENTE`. |
| **SK_VENDEDOR**     | `NUMBER(10)`    | PK/FK | Chave estrangeira para a `DIM_VENDEDOR`. |
| **SK_PRODUTO**      | `NUMBER(10)`    | PK/FK | Chave estrangeira para a `DIM_PRODUTO`. |
| **SK_TEMPO**        | `NUMBER(10)`    | PK/FK | Chave estrangeira para a `DIM_TEMPO`. |
| **SK_LOCALIDADE**   | `NUMBER(10)`    | PK/FK | Chave estrangeira para a `DIM_LOCALIDADE`. |
| **COD_PEDIDO**      | `NUMBER(10)`    | PK    | Código original do pedido. Parte da PK composta. |
| **QUANTIDADE_VENDIDA** | `NUMBER(10)` | Métrica | Quantidade de itens vendidos no pedido. |
| **VALOR_UNITARIO**  | `NUMBER(12,2)`  | Métrica | Preço unitário do produto na venda. |
| **VALOR_DESCONTO**  | `NUMBER(12,2)`  | Métrica | Valor do desconto aplicado ao item. |
| **VALOR_TOTAL_ITEM** | `NUMBER(12,2)` | Métrica | Valor total calculado (Qtd \* Vlr Unit - Desconto). |

---

### 🔹 Tabelas de Dimensão

#### 1. DIM_CLIENTE 👤

**Descrição:** Armazena os atributos descritivos dos clientes.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_CLIENTE**      | `NUMBER(10)`    | PK    | Chave substituta (Surrogate Key) única para o cliente. |
| **COD_CLIENTE_ORIGEM** | `NUMBER(10)` |       | Chave original do cliente no sistema transacional. |
| **NOME_CLIENTE**    | `VARCHAR2(50)`  |       | Nome do cliente. |
| **TIPO_PESSOA**     | `CHAR(1)`       |       | Tipo de pessoa (F - Física, J - Jurídica). |
| **CPF_CNPJ**        | `VARCHAR2(20)`  |       | CPF ou CNPJ do cliente. |

---

#### 2. DIM_VENDEDOR 💼

**Descrição:** Armazena os atributos dos vendedores.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_VENDEDOR**     | `NUMBER(10)`    | PK    | Chave substituta (Surrogate Key) única para o vendedor. |
| **COD_VENDEDOR_ORIGEM** | `NUMBER(4)` |       | Chave original do vendedor no sistema transacional. |
| **NOME_VENDEDOR**   | `VARCHAR2(50)`  |       | Nome do vendedor. |

---

#### 3. DIM_PRODUTO 📦

**Descrição:** Armazena os atributos dos produtos.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_PRODUTO**      | `NUMBER(10)`    | PK    | Chave substituta (Surrogate Key) única para o produto. |
| **COD_PRODUTO_ORIGEM** | `NUMBER(10)` |       | Chave original do produto no sistema transacional. |
| **NOME_PRODUTO**    | `VARCHAR2(50)`  |       | Nome do produto. |
| **COD_BARRA**       | `VARCHAR2(20)`  |       | Código de barras do produto. |

---

#### 4. DIM_TEMPO 📅

**Descrição:** Dimensão de tempo com granularidade diária.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_TEMPO**        | `NUMBER(10)`    | PK    | Chave substituta (Surrogate Key) única para o dia. |
| **DATA_COMPLETA**   | `DATE`          |       | Data completa (ex: 02/09/2025). |
| **DIA**             | `NUMBER(2)`     |       | Dia do mês (1-31). |
| **MES**             | `NUMBER(2)`     |       | Mês do ano (1-12). |
| **ANO**             | `NUMBER(4)`     |       | Ano. |
| **NOME_MES**        | `VARCHAR2(20)`  |       | Nome do mês por extenso (ex: Setembro). |
| **TRIMESTRE**       | `CHAR(2)`       |       | Trimestre do ano (Q1, Q2, Q3, Q4). |
| **SEMESTRE**        | `CHAR(2)`       |       | Semestre do ano (S1, S2). |

---

#### 5. DIM_LOCALIDADE 🌍

**Descrição:** Dimensão geográfica com os dados de localização das vendas.

| Coluna              | Tipo de Dado     | Chave | Descrição |
|---------------------|-----------------|-------|-----------|
| **SK_LOCALIDADE**   | `NUMBER(10)`    | PK    | Chave substituta (Surrogate Key) única para a localidade. |
| **COD_CIDADE_ORIGEM** | `NUMBER(6)`   |       | Chave original da cidade no sistema transacional. |
| **CIDADE**          | `VARCHAR2(30)`  |       | Nome da cidade. |
| **ESTADO**          | `VARCHAR2(50)`  |       | Nome do estado. |
| **PAIS**            | `VARCHAR2(50)`  |       | Nome do país. |
